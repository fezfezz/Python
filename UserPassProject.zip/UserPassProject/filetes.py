import csv


with open('usernames.csv', 'r') as csvfile:
    list = []
    spamreader = csv.reader(csvfile)
    for row in spamreader:
        list.append(row)
        print(list)


# Orignal
import csv
with open('usernames.csv', 'r') as csvfile:
    spamreader = csv.reader(csvfile)
    for row in spamreader:
        usernameString = (', '.join(row))
        print(usernameString)